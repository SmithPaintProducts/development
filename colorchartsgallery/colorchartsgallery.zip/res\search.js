Search={
	makeSlides:true,
	folderThumb:'folderthumb.jpg',
	indexName:'colorchartsgallery.html',
	thumbs:'thumbs',
	slides:'slides',
	ext:'html',
	urlEncode:false,
	sep:'-!-'
};
Search.data=[
	[ '', [  ] ],
	[ 'Color Floor and Color Wall', [ 'colorchartsgallery.html-!-Color Floor and Color Wall-!--!-','Bright Lights Series.png-!-Bright Lights Series-!-Bright Lights Series-!--!--!-0','Old World Series.png-!-Old World Series-!-Old World Series-!--!--!-0','Classic Series.png-!-Classic Series-!-Classic Series-!--!--!-0' ] ],
	[ 'Color Hardener, Cast-On Antique, and Pigment Packs', [ 'colorchartsgallery.html-!-Color Hardener, Cast-On Antique, and Pigment Packs-!--!-','top_colorhard_colorchart.jpg-!-Smith\'s Color Hardener (Part I)-!-Top Half of Smith\'s Color Hardener Color Chart-!--!--!-0','bottom_colorhard_colorchart.jpg-!-Smith\'s Color Hardener (Part II)-!-Bottom Half of Smith\'s Color Hardener Color Chart-!--!--!-0' ] ],
	[ 'Stains, Accents, and Additives', [ 'colorchartsgallery.html-!-Stains, Accents, and Additives-!--!-','Liquid Dye Color Chart.jpg-!-Smith\'s Liquid Dyes Color Chart-!-Liquid Dyes Color Chart-!--!--!-0' ] ]
];